
//  ArgyleTech
//
import SwiftUI
struct ContentView: View {
    @StateObject private var firebase = FirebaseManager.shared
    var body: some View {
        Group {
            if firebase.isLoggedIn {
                if let user = firebase.currentUser {
                    if user.isOlderAdult {
                        ElderTabView()
                    } else {
                        CaretakerTabView()
                    }
                } else {
                    LoadingView()
                }
            } else {
                SplashView()
            }
        }
        .animation(.easeInOut(duration: 0.3), value: firebase.isLoggedIn)
    }
}
struct LoadingView: View {
    var body: some View {
        ZStack {
            Color.appBackground.ignoresSafeArea()
            VStack(spacing: 20) {
                ProgressView()
                    .progressViewStyle(CircularProgressViewStyle(tint: .mintDark))
                    .scaleEffect(1.4)
                Text("Loading...")
                    .font(.appBody(AppFont.bodyMedium))
                    .foregroundColor(.grayText)
            }
        }
    }
}
#Preview {
    ContentView()
}
