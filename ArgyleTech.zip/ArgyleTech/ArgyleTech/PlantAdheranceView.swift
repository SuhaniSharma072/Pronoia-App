


// PlantAdherenceView.swift
import SwiftUI

// MARK: - Plant Stage (based on 7-day streak)

enum PlantStage {
    case seed       // 0 days
    case sprout     // 1 day
    case sapling    // 2–3 days
    case growing    // 4–5 days
    case blooming   // 6 days
    case thriving   // 7 days (full week)

    init(streakDays: Int) {
        switch streakDays {
        case 0:    self = .seed
        case 1:    self = .sprout
        case 2, 3: self = .sapling
        case 4, 5: self = .growing
        case 6:    self = .blooming
        default:   self = .thriving
        }
    }

    var label: String {
        switch self {
        case .seed:     return "Plant your seed 🌱"
        case .sprout:   return "A sprout appears!"
        case .sapling:  return "Growing strong"
        case .growing:  return "Flourishing!"
        case .blooming: return "Almost there..."
        case .thriving: return "Fully thriving! 🌸"
        }
    }

    var message: String {
        switch self {
        case .seed:     return "Take all your medications today to grow your plant"
        case .sprout:   return "Great start — keep going each day!"
        case .sapling:  return "You're building a wonderful habit"
        case .growing:  return "Your plant is loving your dedication"
        case .blooming: return "One more perfect day to bloom!"
        case .thriving: return "7 days strong! Your plant is in full bloom 🌸"
        }
    }

    var soilColor: Color {
        switch self {
        case .seed:               return Color(hex: "#8B6347")
        case .sprout, .sapling:   return Color(hex: "#6B8F3E")
        case .growing, .blooming: return Color(hex: "#4A7A2E")
        case .thriving:           return Color(hex: "#2E6B1E")
        }
    }

    var skyColors: [Color] {
        switch self {
        case .seed:     return [Color(hex: "#D4C5A9"), Color(hex: "#C8B898")]
        case .sprout:   return [Color(hex: "#D8EDD8"), Color(hex: "#B8D8B8")]
        case .sapling:  return [Color(hex: "#C8E8CC"), Color(hex: "#A0CCA4")]
        case .growing:  return [Color(hex: "#B0E0B8"), Color(hex: "#80C088")]
        case .blooming: return [Color(hex: "#98D8A8"), Color(hex: "#60B070")]
        case .thriving: return [Color(hex: "#80CCA0"), Color(hex: "#3DA870")]
        }
    }
}

// MARK: - Main Card

struct PlantAdherenceView: View {

    @StateObject private var firebase = FirebaseManager.shared
    @State private var animatePlant   = false
    @State private var showSparkles   = false

    // Read streak from UserDefaults — set by FirebaseManager daily reset
    var streakDays: Int {
        guard let uid = firebase.currentUser?.id else { return 0 }
        return UserDefaults.standard.integer(forKey: "plantStreakDays_\(uid)")
    }

    // Today's progress (0–1) for the stem height within the current day
    var todayProgress: Double { firebase.adherenceProgress }

    var stage: PlantStage { PlantStage(streakDays: streakDays) }

    var body: some View {
        VStack(spacing: 0) {

            // ── Header row ───────────────────────────────────────────
            HStack(alignment: .top) {
                VStack(alignment: .leading, spacing: 3) {
                    Text("Your Wellness Plant")
                        .font(.appBodyBold(AppFont.bodyMedium))
                        .foregroundColor(.darkText)
                    Text(stage.label)
                        .font(.appCaption(AppFont.tiny))
                        .foregroundColor(.grayText)
                }
                Spacer()
                // Streak badge
                VStack(spacing: 2) {
                    Text("🔥 \(streakDays)/7")
                        .font(.appBodyBold(AppFont.bodySmall))
                        .foregroundColor(streakDays >= 7 ? .mintDark : .coralDark)
                    Text("day streak")
                        .font(.appCaption(AppFont.tiny))
                        .foregroundColor(.grayText)
                }
                .padding(.horizontal, 12).padding(.vertical, 8)
                .background(streakDays >= 7 ? Color.mintLight : Color(hex: "#FFE8E4"))
                .cornerRadius(12)
            }
            .padding(.horizontal, 18)
            .padding(.top, 16)
            .padding(.bottom, 10)

            // ── Plant scene ──────────────────────────────────────────
            ZStack(alignment: .bottom) {
                // Sky
                LinearGradient(colors: stage.skyColors, startPoint: .top, endPoint: .bottom)
                    .cornerRadius(14)
                    .padding(.horizontal, 12)

                // Ground
                RoundedRectangle(cornerRadius: 8)
                    .fill(stage.soilColor)
                    .frame(height: 28)
                    .padding(.horizontal, 20)

                // Plant
                PlantDrawing(streakDays: streakDays, todayProgress: todayProgress, animate: animatePlant)
                    .frame(maxWidth: .infinity)
                    .padding(.bottom, 24)

                // Sparkles on full week
                if showSparkles { SparkleOverlay().padding(.bottom, 30) }
            }
            .frame(height: 220)
            .padding(.horizontal, 0)

            // ── 7-day dot track ──────────────────────────────────────
            HStack(spacing: 8) {
                ForEach(0..<7, id: \.self) { day in
                    VStack(spacing: 4) {
                        Circle()
                            .fill(day < streakDays ? Color.mintDark : Color.lightGray)
                            .frame(width: 10, height: 10)
                        Text(dayLabel(offset: day))
                            .font(.appCaption(AppFont.tiny))
                            .foregroundColor(day < streakDays ? .mintDark : .grayText)
                    }
                    .frame(maxWidth: .infinity)
                }
            }
            .padding(.horizontal, 18)
            .padding(.vertical, 10)

            // ── Today's progress bar ─────────────────────────────────
            VStack(spacing: 4) {
                HStack {
                    Text("Today")
                        .font(.appCaption(AppFont.tiny))
                        .foregroundColor(.grayText)
                    Spacer()
                    Text("\(Int(todayProgress * 100))%")
                        .font(.appBodyBold(AppFont.tiny))
                        .foregroundColor(todayProgress >= 1.0 ? .mintDark : .coralDark)
                }
                GeometryReader { geo in
                    ZStack(alignment: .leading) {
                        RoundedRectangle(cornerRadius: 4).fill(Color.lightGray).frame(height: 8)
                        RoundedRectangle(cornerRadius: 4)
                            .fill(todayProgress >= 1.0 ? Color.mintDark : Color.coral)
                            .frame(width: geo.size.width * todayProgress, height: 8)
                            .animation(.easeInOut, value: todayProgress)
                    }
                }
                .frame(height: 8)
            }
            .padding(.horizontal, 18)
            .padding(.bottom, 6)

            // ── Message ──────────────────────────────────────────────
            Text(stage.message)
                .font(.appBody(AppFont.bodySmall))
                .foregroundColor(.grayText)
                .multilineTextAlignment(.center)
                .padding(.horizontal, 18)
                .padding(.bottom, 14)
        }
        .background(Color.white)
        .cornerRadius(20)
        .shadow(color: .shadowColor, radius: 8, x: 0, y: 4)
        .onAppear {
            withAnimation(.spring(response: 0.7, dampingFraction: 0.65).delay(0.2)) {
                animatePlant = true
            }
            showSparkles = streakDays >= 7
        }
        .onChange(of: firebase.adherenceProgress) { _, _ in
            withAnimation(.spring(response: 0.5, dampingFraction: 0.6)) {
                animatePlant = true
            }
        }
    }

    private func dayLabel(offset: Int) -> String {
        let startDay = Calendar.current.date(
            byAdding: .day, value: -(streakDays - 1 - offset), to: Date()
        ) ?? Date()
        let f = DateFormatter(); f.dateFormat = "E"
        return String(f.string(from: startDay).prefix(1))
    }
}

// MARK: - Plant Drawing

struct PlantDrawing: View {
    let streakDays:   Int
    let todayProgress: Double
    let animate:       Bool

    // Stem height based on streak (0–120pt over 7 days)
    var stemHeight: CGFloat {
        let streakFraction = Double(streakDays) / 7.0
        // Blend streak progress with today's partial progress
        let blended = streakFraction + (todayProgress / 7.0)
        return CGFloat(min(blended, 1.0)) * 120
    }

    var body: some View {
        ZStack(alignment: .bottom) {

            // Seed (day 0, no meds taken yet today)
            if streakDays == 0 && todayProgress == 0 {
                Ellipse()
                    .fill(Color(hex: "#8B6347"))
                    .frame(width: 20, height: 13)
                    .opacity(animate ? 1 : 0)
                    .animation(.easeIn(duration: 0.4), value: animate)
            }

            // Stem
            if streakDays > 0 || todayProgress > 0 {
                Capsule()
                    .fill(Color(hex: "#4A8C3E"))
                    .frame(width: 8, height: animate ? stemHeight : 4)
                    .animation(.spring(response: 0.8, dampingFraction: 0.65), value: animate)
            }

            // Small leaves — day 1+
            if streakDays >= 1 {
                LeafShape()
                    .fill(Color(hex: "#5BBE50"))
                    .frame(width: 36, height: 20)
                    .rotationEffect(.degrees(-35))
                    .offset(x: -26, y: animate ? -(stemHeight * 0.45) : -8)
                    .opacity(animate ? 1 : 0)
                    .animation(.spring(response: 0.65, dampingFraction: 0.7).delay(0.12), value: animate)

                LeafShape()
                    .fill(Color(hex: "#4AAF45"))
                    .frame(width: 32, height: 18)
                    .rotationEffect(.degrees(35))
                    .scaleEffect(x: -1)
                    .offset(x: 24, y: animate ? -(stemHeight * 0.55) : -14)
                    .opacity(animate ? 1 : 0)
                    .animation(.spring(response: 0.65, dampingFraction: 0.7).delay(0.18), value: animate)
            }

            // Mid leaves — day 3+
            if streakDays >= 3 {
                LeafShape()
                    .fill(Color(hex: "#3DA835"))
                    .frame(width: 46, height: 26)
                    .rotationEffect(.degrees(-22))
                    .offset(x: -34, y: animate ? -(stemHeight * 0.65) : -24)
                    .opacity(animate ? 1 : 0)
                    .animation(.spring(response: 0.65, dampingFraction: 0.7).delay(0.24), value: animate)

                LeafShape()
                    .fill(Color(hex: "#48C040"))
                    .frame(width: 42, height: 24)
                    .rotationEffect(.degrees(22))
                    .scaleEffect(x: -1)
                    .offset(x: 32, y: animate ? -(stemHeight * 0.75) : -32)
                    .opacity(animate ? 1 : 0)
                    .animation(.spring(response: 0.65, dampingFraction: 0.7).delay(0.28), value: animate)
            }

            // Top leaves — day 5+
            if streakDays >= 5 {
                LeafShape()
                    .fill(Color(hex: "#2E9E55"))
                    .frame(width: 38, height: 22)
                    .rotationEffect(.degrees(-15))
                    .offset(x: -28, y: animate ? -(stemHeight * 0.85) : -44)
                    .opacity(animate ? 1 : 0)
                    .animation(.spring(response: 0.65, dampingFraction: 0.7).delay(0.3), value: animate)

                LeafShape()
                    .fill(Color(hex: "#36B84E"))
                    .frame(width: 36, height: 20)
                    .rotationEffect(.degrees(15))
                    .scaleEffect(x: -1)
                    .offset(x: 26, y: animate ? -(stemHeight * 0.9) : -50)
                    .opacity(animate ? 1 : 0)
                    .animation(.spring(response: 0.65, dampingFraction: 0.7).delay(0.32), value: animate)
            }

            // Flower — day 6+
            if streakDays >= 6 {
                let isFull = streakDays >= 7
                FlowerShape(petals: isFull ? 8 : 5, isFull: isFull)
                    .offset(y: animate ? -(stemHeight + 18) : -(stemHeight))
                    .opacity(animate ? 1 : 0)
                    .scaleEffect(animate ? 1 : 0.1)
                    .animation(.spring(response: 0.55, dampingFraction: 0.55).delay(0.36), value: animate)
            }
        }
    }
}

// MARK: - Leaf Shape

struct LeafShape: Shape {
    func path(in rect: CGRect) -> Path {
        var path = Path()
        path.move(to: CGPoint(x: rect.midX, y: rect.maxY))
        path.addQuadCurve(
            to:      CGPoint(x: rect.midX, y: rect.minY),
            control: CGPoint(x: rect.maxX, y: rect.midY)
        )
        path.addQuadCurve(
            to:      CGPoint(x: rect.midX, y: rect.maxY),
            control: CGPoint(x: rect.minX, y: rect.midY)
        )
        return path
    }
}

// MARK: - Flower Shape

struct FlowerShape: View {
    let petals:  Int
    let isFull:  Bool

    var petalColor:  Color { isFull ? Color(hex: "#FF85A1") : Color(hex: "#FFB347") }
    var centerColor: Color { isFull ? Color(hex: "#FFD700") : Color(hex: "#FFF176") }

    var body: some View {
        ZStack {
            ForEach(0..<petals, id: \.self) { i in
                Ellipse()
                    .fill(petalColor)
                    .frame(width: 13, height: 21)
                    .offset(y: -12)
                    .rotationEffect(.degrees(Double(i) * (360.0 / Double(petals))))
            }
            Circle().fill(centerColor).frame(width: 15, height: 15)
        }
        .frame(width: 48, height: 48)
    }
}

// MARK: - Sparkle Overlay

struct SparkleOverlay: View {
    @State private var animate = false

    let items: [(CGFloat, CGFloat, CGFloat)] = [
        (-55, -60, 14), (50, -70, 11), (-38, 5, 16),
        (52, -5, 12),   (0, -90, 10), (-65, 25, 13), (60, 35, 15)
    ]

    var body: some View {
        ZStack {
            ForEach(items.indices, id: \.self) { i in
                Text("✨")
                    .font(.system(size: items[i].2))
                    .offset(x: items[i].0, y: items[i].1)
                    .opacity(animate ? 1 : 0)
                    .scaleEffect(animate ? 1 : 0.3)
                    .animation(
                        .easeInOut(duration: 0.9)
                        .repeatForever(autoreverses: true)
                        .delay(Double(i) * 0.13),
                        value: animate
                    )
            }
        }
        .onAppear { animate = true }
    }
}

#Preview {
    ScrollView {
        PlantAdherenceView().padding(20)
    }
    .background(Color.appBackground)
}
