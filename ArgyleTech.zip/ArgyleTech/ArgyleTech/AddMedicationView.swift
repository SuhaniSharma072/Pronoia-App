
import SwiftUI
import UserNotifications

struct AddMedicationView: View {

    @StateObject private var firebase = FirebaseManager.shared

    @State private var medicationName = ""
    @State private var dosage         = ""
    @State private var frequency      = ""
    @State private var notes          = ""
    @State private var pillCount      = ""
    @State private var durationDays   = ""
    @State private var refillAt       = ""
    @State private var times: [String] = []
    @State private var newTime        = ""
    @State private var showError      = false
    @State private var errorMessage   = ""
    @State private var isSaving       = false

    var body: some View {
        NavigationView {
            ZStack {
                Color(.systemGroupedBackground).ignoresSafeArea()

                ScrollView {
                    VStack(spacing: 20) {

                        Text("Add Medication")
                            .font(.largeTitle)
                            .fontWeight(.bold)
                            .padding(.top)

                        fieldView(label: "Medication Name", placeholder: "e.g. Ibuprofen",   icon: "pills",                    text: $medicationName)
                        fieldView(label: "Dosage",          placeholder: "e.g. 200mg",        icon: "scalemass",                text: $dosage)
                        fieldView(label: "Frequency",       placeholder: "e.g. Twice a day",  icon: "clock",                    text: $frequency)
                        fieldView(label: "Total Pill Count",placeholder: "e.g. 30",           icon: "pills.fill",               text: $pillCount)
                        fieldView(label: "Refill Alert At (pills)", placeholder: "e.g. 5",    icon: "exclamationmark.triangle", text: $refillAt)
                        fieldView(label: "Duration (days)", placeholder: "e.g. 10",           icon: "calendar",                 text: $durationDays)

                        // Times
                        VStack(alignment: .leading, spacing: 8) {
                            Text("Times to Take").font(.headline)

                            HStack {
                                TextField("e.g. 8:00 AM", text: $newTime)
                                    .textFieldStyle(.roundedBorder)

                                Button("Add") {
                                    if !newTime.isEmpty {
                                        times.append(newTime)
                                        newTime = ""
                                    }
                                }
                            }

                            ForEach(times, id: \.self) { time in
                                Text(time)
                                    .padding(6)
                                    .background(Color.white)
                                    .cornerRadius(8)
                            }
                        }

                        // Notes
                        VStack(alignment: .leading, spacing: 8) {
                            Text("Notes").font(.headline)

                            HStack(alignment: .top) {
                                Image(systemName: "note.text").foregroundColor(.gray)
                                TextField("Optional notes...", text: $notes, axis: .vertical)
                                    .lineLimit(3...6)
                            }
                            .padding()
                            .background(Color.white)
                            .cornerRadius(10)
                            .overlay(RoundedRectangle(cornerRadius: 10).stroke(Color.gray.opacity(0.3)))
                        }

                        if showError {
                            Text(errorMessage)
                                .foregroundColor(.red)
                                .font(.subheadline)
                        }

                        Button(action: saveMedication) {
                            ZStack {
                                if isSaving {
                                    ProgressView()
                                } else {
                                    Text("Save Medication")
                                        .foregroundColor(.white)
                                        .fontWeight(.semibold)
                                }
                            }
                            .frame(maxWidth: .infinity)
                            .frame(height: 50)
                            .background(Color.mintDark)
                            .cornerRadius(12)
                        }
                        .padding(.top)

                        Spacer()
                    }
                    .padding()
                }
            }
            .navigationBarHidden(true)
            .onAppear { NotificationManager.shared.requestPermission() }
        }
    }

    private func fieldView(label: String, placeholder: String, icon: String, text: Binding<String>) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(label).font(.headline)

            HStack {
                Image(systemName: icon).foregroundColor(.gray)
                TextField(placeholder, text: text)
            }
            .padding()
            .background(Color.white)
            .cornerRadius(10)
            .overlay(RoundedRectangle(cornerRadius: 10).stroke(Color.gray.opacity(0.3)))
        }
    }

    private func saveMedication() {
        guard !medicationName.isEmpty else { showError("Please enter medication name"); return }
        guard !dosage.isEmpty         else { showError("Please enter dosage");          return }

        let pills    = Int(pillCount)    ?? 0
        let duration = Int(durationDays) ?? 0
        let refill   = Int(refillAt)     ?? 5

        isSaving = true

        firebase.saveMedication(
            name:         medicationName,
            dosage:       dosage,
            frequency:    frequency,
            times:        times,
            durationDays: duration,
            pillCount:    pills,
            refillAt:     refill,
            notes:        notes
        ) { success, error in
            DispatchQueue.main.async {
                isSaving = false
                if success {
                    NotificationManager.shared.scheduleMedicationNotifications(
                        medName: medicationName,
                        times:   times
                    )
                    clearForm()
                } else {
                    showError(error ?? "Failed to save medication")
                }
            }
        }
    }

    private func showError(_ message: String) {
        errorMessage = message
        showError    = true
    }

    private func clearForm() {
        medicationName = ""; dosage = ""; frequency = ""; notes = ""
        pillCount = ""; durationDays = ""; refillAt = ""
        times = []; newTime = ""
        showError = false
    }
}

#Preview {
    AddMedicationView()
}
