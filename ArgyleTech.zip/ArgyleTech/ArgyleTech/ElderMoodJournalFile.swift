// ElderMoodJournalView.swift
import SwiftUI

struct ElderMoodJournalView: View {

    @StateObject private var firebase  = FirebaseManager.shared
    @Environment(\.dismiss) private var dismiss
    @State private var expandedEntryID: String? = nil

    var elderName: String { firebase.linkedElder?.name ?? "Elder" }

    var groupedEntries: [(String, [MoodEntry])] {
        let entries = firebase.elderMoodEntries
        var dict: [(String, [MoodEntry])] = []
        var seen: [String] = []

        for entry in entries {
            let monthKey = monthLabel(from: entry.date)
            if !seen.contains(monthKey) {
                seen.append(monthKey)
                dict.append((monthKey, []))
            }
            if let idx = dict.firstIndex(where: { $0.0 == monthKey }) {
                dict[idx].1.append(entry)
            }
        }
        return dict
    }

    var body: some View {
        NavigationStack {
            ZStack {
                Color.appBackground.ignoresSafeArea()

                ScrollView(showsIndicators: false) {
                    VStack(spacing: 0) {

                        ZStack(alignment: .bottomLeading) {
                            LinearGradient.mintHeader
                                .frame(height: 140)
                                .ignoresSafeArea()
                            VStack(alignment: .leading, spacing: 4) {
                                Text("\(elderName)'s Journal")
                                    .font(.appBody(AppFont.bodyMedium))
                                    .foregroundColor(.mintLight)
                                Text("Mood History")
                                    .font(.appTitle(AppFont.displayMedium))
                                    .foregroundColor(.white)
                            }
                            .padding(.horizontal, 22)
                            .padding(.bottom, 20)
                        }

                        if !firebase.elderMoodEntries.isEmpty {
                            ScrollView(.horizontal, showsIndicators: false) {
                                HStack(spacing: 12) {
                                    ForEach(MoodOption.allCases, id: \.self) { mood in
                                        let count = firebase.elderMoodEntries
                                            .filter { $0.mood == mood.rawValue }.count
                                        if count > 0 {
                                            VStack(spacing: 4) {
                                                Text(mood.emoji).font(.system(size: 26))
                                                Text("\(count)×")
                                                    .font(.appBodyBold(AppFont.bodySmall))
                                                    .foregroundColor(.darkText)
                                                Text(mood.label)
                                                    .font(.appCaption(AppFont.tiny))
                                                    .foregroundColor(.grayText)
                                            }
                                            .padding(12)
                                            .background(Color.white)
                                            .cornerRadius(14)
                                            .shadow(color: .shadowColor, radius: 3, x: 0, y: 2)
                                        }
                                    }
                                }
                                .padding(.horizontal, 20)
                                .padding(.vertical, 16)
                            }
                        }

                        VStack(spacing: 20) {
                            if firebase.elderMoodEntries.isEmpty {
                                VStack(spacing: 16) {
                                    Text("📔").font(.system(size: 50))
                                    Text("No journal entries yet")
                                        .font(.appBodyBold(AppFont.titleMedium))
                                        .foregroundColor(.darkText)
                                    Text("\(elderName) hasn't logged any mood entries yet.")
                                        .font(.appBody(AppFont.bodyMedium))
                                        .foregroundColor(.grayText)
                                        .multilineTextAlignment(.center)
                                }
                                .padding(40)
                                .frame(maxWidth: .infinity)
                                .background(Color.white)
                                .cornerRadius(20)
                                .padding(.horizontal, 20)
                            } else {
                                ForEach(groupedEntries, id: \.0) { month, entries in
                                    VStack(alignment: .leading, spacing: 10) {
                                        Text(month)
                                            .font(.appBodyBold(AppFont.bodyMedium))
                                            .foregroundColor(.grayText)
                                            .padding(.horizontal, 20)

                                        ForEach(entries) { entry in
                                            ReadOnlyMoodEntryCard(
                                                entry:      entry,
                                                isExpanded: expandedEntryID == entry.id,
                                                onTap: {
                                                    withAnimation(.spring(
                                                        response: 0.4, dampingFraction: 0.75
                                                    )) {
                                                        expandedEntryID =
                                                            expandedEntryID == entry.id
                                                            ? nil : entry.id
                                                    }
                                                }
                                            )
                                            .padding(.horizontal, 20)
                                        }
                                    }
                                }
                            }

                            Spacer().frame(height: 100)
                        }
                    }
                }
            }
            .navigationBarHidden(true)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button { dismiss() } label: {
                        Image(systemName: "chevron.left").foregroundColor(.mintDark)
                    }
                }
            }
        }
    }

    private func monthLabel(from dateStr: String) -> String {
        let formats = ["MMM d, yyyy", "MMM d", "yyyy-MM-dd"]
        for fmt in formats {
            let f = DateFormatter(); f.dateFormat = fmt
            if let date = f.date(from: dateStr) {
                let out = DateFormatter(); out.dateFormat = "MMMM yyyy"
                return out.string(from: date)
            }
        }
        return dateStr.isEmpty ? "Unknown" : String(dateStr.prefix(8))
    }
}

// MARK: - Read-Only Mood Entry Card

struct ReadOnlyMoodEntryCard: View {
    let entry:      MoodEntry
    let isExpanded: Bool
    let onTap:      () -> Void

    var moodColor: Color {
        switch entry.mood {
        case "great":   return .mintDark
        case "okay":    return Color(hex: "#5B9BD5")
        case "low":     return .grayText
        case "anxious": return .coral
        case "tired":   return Color(hex: "#9B7FD4")
        default:        return .mintDark
        }
    }

    var moodBg: Color {
        switch entry.mood {
        case "great":   return Color.mintLight
        case "okay":    return Color(hex: "#E8F0FB")
        case "low":     return Color.lightGray
        case "anxious": return Color(hex: "#FFE8E4")
        case "tired":   return Color(hex: "#EDE8F5")
        default:        return Color.mintLight
        }
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {

            Button(action: onTap) {
                HStack(spacing: 14) {
                    ZStack {
                        Circle().fill(moodBg).frame(width: 50, height: 50)
                        Text(entry.moodEmoji).font(.system(size: 26))
                    }
                    VStack(alignment: .leading, spacing: 3) {
                        Text(entry.mood.capitalized)
                            .font(.appBodyBold(AppFont.bodyMedium))
                            .foregroundColor(moodColor)
                        Text(entry.date)
                            .font(.appCaption(AppFont.tiny))
                            .foregroundColor(.grayText)
                    }
                    Spacer()
                    if !entry.symptoms.isEmpty {
                        Text("\(entry.symptoms.count) symptom\(entry.symptoms.count == 1 ? "" : "s")")
                            .font(.appCaption(AppFont.tiny))
                            .foregroundColor(.coralDark)
                            .padding(.horizontal, 8).padding(.vertical, 4)
                            .background(Color(hex: "#FFE8E4")).cornerRadius(99)
                    }
                    Image(systemName: isExpanded ? "chevron.up" : "chevron.down")
                        .font(.system(size: 13, weight: .semibold))
                        .foregroundColor(.grayText)
                }
                .padding(16)
            }
            .buttonStyle(.plain)

            if isExpanded {
                Divider().padding(.horizontal, 16)

                VStack(alignment: .leading, spacing: 14) {
                    if !entry.notes.isEmpty {
                        VStack(alignment: .leading, spacing: 6) {
                            Label("Notes", systemImage: "note.text")
                                .font(.appBodyBold(AppFont.bodySmall))
                                .foregroundColor(.grayText)
                            Text(entry.notes)
                                .font(.appBody(AppFont.bodyMedium))
                                .foregroundColor(.darkText)
                                .fixedSize(horizontal: false, vertical: true)
                        }
                    } else {
                        Text("No notes for this entry.")
                            .font(.appBody(AppFont.bodySmall))
                            .foregroundColor(.grayText)
                            .italic()
                    }

                    if !entry.symptoms.isEmpty {
                        VStack(alignment: .leading, spacing: 8) {
                            Label("Symptoms", systemImage: "staroflife.fill")
                                .font(.appBodyBold(AppFont.bodySmall))
                                .foregroundColor(.grayText)
                            FlexWrap(items: entry.symptoms) { symptom in
                                Text(symptom)
                                    .font(.appCaption(AppFont.tiny))
                                    .foregroundColor(.coralDark)
                                    .padding(.horizontal, 10).padding(.vertical, 5)
                                    .background(Color(hex: "#FFE8E4")).cornerRadius(99)
                            }
                        }
                    }
                }
                .padding(.horizontal, 16)
                .padding(.vertical, 14)
                .transition(.opacity.combined(with: .move(edge: .top)))
            }
        }
        .background(Color.white)
        .cornerRadius(18)
        .overlay(
            RoundedRectangle(cornerRadius: 18)
                .stroke(isExpanded ? moodColor.opacity(0.4) : Color.clear, lineWidth: 2)
        )
        .shadow(color: .shadowColor, radius: 6, x: 0, y: 3)
        .animation(.spring(response: 0.4, dampingFraction: 0.75), value: isExpanded)
    }
}

#Preview {
    ElderMoodJournalView()
}
