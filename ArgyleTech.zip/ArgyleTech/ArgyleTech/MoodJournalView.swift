// MoodJournalView.swift
import SwiftUI

struct MoodJournalView: View {

    @StateObject private var firebase = FirebaseManager.shared
    @Environment(\.dismiss) private var dismiss

    @State private var selectedTab      = 0
    @State private var selectedMood:     MoodOption? = nil
    @State private var notes             = ""
    @State private var selectedSymptoms: Set<String> = []
    @State private var isSaving          = false
    @State private var showSuccess       = false
    @State private var expandedEntryID:  String?     = nil

    let symptoms = [
        "Headache", "Nausea", "Dizziness", "Fatigue",
        "Appetite loss", "Chest pain", "Shortness of breath",
        "Joint pain", "Stomach upset", "Blurred vision"
    ]

    var body: some View {
        NavigationStack {
            ZStack {
                Color.appBackground.ignoresSafeArea()

                VStack(spacing: 0) {

                    Picker("", selection: $selectedTab) {
                        Text("Log Today").tag(0)
                        Text("History (\(firebase.moodEntries.count))").tag(1)
                    }
                    .pickerStyle(.segmented)
                    .padding(.horizontal, 20)
                    .padding(.vertical, 12)

                    if selectedTab == 0 {
                        logView
                    } else {
                        historyView
                    }
                }
            }
            .navigationTitle("Mood Journal")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("Done") { dismiss() }.foregroundColor(.mintDark)
                }
            }
        }
    }

    // MARK: - Log Tab

    var logView: some View {
        ScrollView(showsIndicators: false) {
            VStack(spacing: 24) {

                VStack(alignment: .leading, spacing: 14) {
                    Text("How are you feeling today?").sectionTitle()

                    HStack(spacing: 0) {
                        ForEach(MoodOption.allCases, id: \.self) { mood in
                            Button {
                                withAnimation(.spring(response: 0.3)) { selectedMood = mood }
                            } label: {
                                VStack(spacing: 8) {
                                    Text(mood.emoji)
                                        .font(.system(size: 34))
                                        .scaleEffect(selectedMood == mood ? 1.3 : 1.0)
                                    Text(mood.label)
                                        .font(.appCaption(AppFont.tiny))
                                        .foregroundColor(selectedMood == mood ? .mintDark : .grayText)
                                }
                                .frame(maxWidth: .infinity)
                                .padding(.vertical, 14)
                                .background(selectedMood == mood ? Color.mintLight : Color.clear)
                                .cornerRadius(14)
                            }
                        }
                    }
                    .padding(8)
                    .background(Color.white)
                    .cornerRadius(18)
                    .shadow(color: .shadowColor, radius: 6, x: 0, y: 3)
                }

                VStack(alignment: .leading, spacing: 10) {
                    Text("Notes").sectionTitle()
                    TextField(
                        "How are you feeling? Any changes since your last medication?",
                        text: $notes, axis: .vertical
                    )
                    .font(.appBody(AppFont.bodyMedium))
                    .lineLimit(4...8)
                    .padding(16)
                    .background(Color.white)
                    .cornerRadius(16)
                    .shadow(color: .shadowColor, radius: 4, x: 0, y: 2)
                }

                VStack(alignment: .leading, spacing: 12) {
                    Text("Any Symptoms?").sectionTitle()
                    Text("Tap all that apply")
                        .font(.appCaption()).foregroundColor(.grayText)

                    LazyVGrid(
                        columns: [GridItem(.flexible()), GridItem(.flexible())],
                        spacing: 10
                    ) {
                        ForEach(symptoms, id: \.self) { symptom in
                            let selected = selectedSymptoms.contains(symptom)
                            Button {
                                if selected { selectedSymptoms.remove(symptom) }
                                else        { selectedSymptoms.insert(symptom) }
                            } label: {
                                HStack {
                                    Image(systemName: selected
                                          ? "checkmark.circle.fill" : "circle")
                                        .foregroundColor(selected ? .mintDark : .grayText)
                                    Text(symptom)
                                        .font(.appBody(AppFont.bodySmall))
                                        .foregroundColor(selected ? .mintDark : .darkText)
                                    Spacer()
                                }
                                .padding(12)
                                .background(selected ? Color.mintLight : Color.white)
                                .cornerRadius(12)
                                .overlay(
                                    RoundedRectangle(cornerRadius: 12)
                                        .stroke(selected ? Color.mintDark : Color.lightGray,
                                                lineWidth: selected ? 2 : 1)
                                )
                            }
                        }
                    }
                }

                if showSuccess {
                    HStack {
                        Image(systemName: "checkmark.circle.fill").foregroundColor(.mintDark)
                        Text("Entry saved! 🌿")
                            .font(.appBodyBold(AppFont.bodyMedium))
                            .foregroundColor(.mintDark)
                    }
                    .padding(16)
                    .frame(maxWidth: .infinity)
                    .background(Color.mintLight)
                    .cornerRadius(14)
                }

                Button { saveMood() } label: {
                    ZStack {
                        if isSaving {
                            ProgressView()
                                .progressViewStyle(CircularProgressViewStyle(tint: .white))
                        } else {
                            HStack {
                                Image(systemName: "heart.fill")
                                Text("Save Entry").font(.appButton(AppFont.bodyLarge))
                            }
                            .foregroundColor(.white)
                        }
                    }
                    .frame(maxWidth: .infinity).frame(height: 56)
                    .background(selectedMood == nil ? Color.grayText : Color.mintDark)
                    .cornerRadius(16)
                }
                .disabled(selectedMood == nil || isSaving)

                Spacer().frame(height: 40)
            }
            .padding(.horizontal, 22)
            .padding(.top, 8)
        }
    }

    // MARK: - History Tab

    var historyView: some View {
        ScrollView(showsIndicators: false) {
            VStack(spacing: 12) {

                if firebase.moodEntries.isEmpty {
                    VStack(spacing: 16) {
                        Text("📔").font(.system(size: 50))
                        Text("No entries yet")
                            .font(.appBodyBold(AppFont.titleMedium))
                            .foregroundColor(.darkText)
                        Text("Start logging your mood to build your journal")
                            .font(.appBody(AppFont.bodyMedium))
                            .foregroundColor(.grayText)
                            .multilineTextAlignment(.center)
                    }
                    .padding(40)
                    .frame(maxWidth: .infinity)
                    .background(Color.white)
                    .cornerRadius(20)
                    .padding(.horizontal, 20)
                    .padding(.top, 12)
                } else {
                    ForEach(firebase.moodEntries) { entry in
                        MoodEntryCard(
                            entry:      entry,
                            isExpanded: expandedEntryID == entry.id,
                            onTap: {
                                withAnimation(.spring(response: 0.4, dampingFraction: 0.75)) {
                                    expandedEntryID = expandedEntryID == entry.id ? nil : entry.id
                                }
                            },
                            onDelete: {
                                guard let userID = firebase.currentUser?.id else { return }
                                firebase.deleteMoodEntry(userID: userID, entryID: entry.id) { _ in }
                            }
                        )
                        .padding(.horizontal, 20)
                    }
                }

                Spacer().frame(height: 100)
            }
            .padding(.top, 8)
        }
    }

    // MARK: - Save

    private func saveMood() {
        guard let mood   = selectedMood,
              let userID = firebase.currentUser?.id else { return }
        isSaving = true
        firebase.saveMood(
            userID:   userID,
            mood:     mood.rawValue,
            emoji:    mood.emoji,
            notes:    notes,
            symptoms: Array(selectedSymptoms)
        ) { success in
            DispatchQueue.main.async {
                isSaving = false
                if success {
                    withAnimation { showSuccess = true }
                    selectedMood     = nil
                    notes            = ""
                    selectedSymptoms = []
                    DispatchQueue.main.asyncAfter(deadline: .now() + 1.2) {
                        withAnimation { showSuccess = false }
                        selectedTab = 1
                    }
                }
            }
        }
    }
}

// MARK: - Mood Entry Card

struct MoodEntryCard: View {
    let entry:      MoodEntry
    let isExpanded: Bool
    let onTap:      () -> Void
    let onDelete:   () -> Void

    @State private var confirmDelete = false

    var moodColor: Color {
        switch entry.mood {
        case "great":   return .mintDark
        case "okay":    return Color(hex: "#5B9BD5")
        case "low":     return .grayText
        case "anxious": return .coral
        case "tired":   return Color(hex: "#9B7FD4")
        default:        return .mintDark
        }
    }

    var moodBg: Color {
        switch entry.mood {
        case "great":   return Color.mintLight
        case "okay":    return Color(hex: "#E8F0FB")
        case "low":     return Color.lightGray
        case "anxious": return Color(hex: "#FFE8E4")
        case "tired":   return Color(hex: "#EDE8F5")
        default:        return Color.mintLight
        }
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {

            Button(action: onTap) {
                HStack(spacing: 14) {
                    ZStack {
                        Circle().fill(moodBg).frame(width: 50, height: 50)
                        Text(entry.moodEmoji).font(.system(size: 26))
                    }
                    VStack(alignment: .leading, spacing: 3) {
                        Text(entry.mood.capitalized)
                            .font(.appBodyBold(AppFont.bodyMedium))
                            .foregroundColor(moodColor)
                        Text(entry.date)
                            .font(.appCaption(AppFont.tiny))
                            .foregroundColor(.grayText)
                    }
                    Spacer()
                    if !entry.symptoms.isEmpty {
                        Text("\(entry.symptoms.count) symptom\(entry.symptoms.count == 1 ? "" : "s")")
                            .font(.appCaption(AppFont.tiny))
                            .foregroundColor(.coralDark)
                            .padding(.horizontal, 8).padding(.vertical, 4)
                            .background(Color(hex: "#FFE8E4")).cornerRadius(99)
                    }
                    Image(systemName: isExpanded ? "chevron.up" : "chevron.down")
                        .font(.system(size: 13, weight: .semibold))
                        .foregroundColor(.grayText)
                }
                .padding(16)
            }
            .buttonStyle(.plain)

            if isExpanded {
                Divider().padding(.horizontal, 16)

                VStack(alignment: .leading, spacing: 14) {
                    if !entry.notes.isEmpty {
                        VStack(alignment: .leading, spacing: 6) {
                            Label("Notes", systemImage: "note.text")
                                .font(.appBodyBold(AppFont.bodySmall))
                                .foregroundColor(.grayText)
                            Text(entry.notes)
                                .font(.appBody(AppFont.bodyMedium))
                                .foregroundColor(.darkText)
                                .fixedSize(horizontal: false, vertical: true)
                        }
                    } else {
                        Text("No notes for this entry.")
                            .font(.appBody(AppFont.bodySmall))
                            .foregroundColor(.grayText)
                            .italic()
                    }

                    if !entry.symptoms.isEmpty {
                        VStack(alignment: .leading, spacing: 8) {
                            Label("Symptoms", systemImage: "staroflife.fill")
                                .font(.appBodyBold(AppFont.bodySmall))
                                .foregroundColor(.grayText)
                            FlexWrap(items: entry.symptoms) { symptom in
                                Text(symptom)
                                    .font(.appCaption(AppFont.tiny))
                                    .foregroundColor(.coralDark)
                                    .padding(.horizontal, 10).padding(.vertical, 5)
                                    .background(Color(hex: "#FFE8E4")).cornerRadius(99)
                            }
                        }
                    }

                    Button { confirmDelete = true } label: {
                        HStack(spacing: 6) {
                            Image(systemName: "trash.fill").font(.system(size: 12))
                            Text("Delete Entry").font(.appBodyBold(AppFont.bodySmall))
                        }
                        .foregroundColor(.coralDark)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 10)
                        .background(Color(hex: "#FFE8E4"))
                        .cornerRadius(10)
                    }
                    .confirmationDialog(
                        "Delete this entry?",
                        isPresented: $confirmDelete,
                        titleVisibility: .visible
                    ) {
                        Button("Delete", role: .destructive) { onDelete() }
                        Button("Cancel", role: .cancel) {}
                    }
                }
                .padding(.horizontal, 16)
                .padding(.vertical, 14)
                .transition(.opacity.combined(with: .move(edge: .top)))
            }
        }
        .background(Color.white)
        .cornerRadius(18)
        .overlay(
            RoundedRectangle(cornerRadius: 18)
                .stroke(isExpanded ? moodColor.opacity(0.4) : Color.clear, lineWidth: 2)
        )
        .shadow(color: .shadowColor, radius: 6, x: 0, y: 3)
        .animation(.spring(response: 0.4, dampingFraction: 0.75), value: isExpanded)
    }
}

// MARK: - Flex Wrap

struct FlexWrap<Item: Hashable, Content: View>: View {
    let items:   [Item]
    let content: (Item) -> Content

    @State private var height: CGFloat = 0

    var body: some View {
        GeometryReader { geo in
            wrap(in: geo.size.width)
        }
        .frame(height: height)
    }

    private func wrap(in totalWidth: CGFloat) -> some View {
        var x: CGFloat = 0
        var y: CGFloat = 0
        let itemHeight: CGFloat = 28
        let spacing: CGFloat    = 8

        return ZStack(alignment: .topLeading) {
            ForEach(items, id: \.self) { item in
                content(item)
                    .fixedSize()
                    .alignmentGuide(.leading) { d in
                        if x + d.width > totalWidth { x = 0; y -= itemHeight + spacing }
                        let result = -x
                        x += d.width + spacing
                        if item == items.last { x = 0 }
                        return result
                    }
                    .alignmentGuide(.top) { _ in
                        let result = y
                        if item == items.last { y = 0 }
                        return result
                    }
            }
        }
        .background(
            GeometryReader { g -> Color in
                DispatchQueue.main.async { height = max(g.size.height, itemHeight) }
                return .clear
            }
        )
    }
}

#Preview {
    MoodJournalView()
}
