
// FamilyView.swift
import SwiftUI
import MessageUI

struct FamilyView: View {

    @StateObject private var firebase = FirebaseManager.shared
    @State private var showMessageComposer = false
    @State private var showNoPhoneAlert    = false

    var caretakerInitials: String {
        let parts = (firebase.currentUser?.caretakerName ?? "C")
            .components(separatedBy: " ")
        return parts.compactMap { $0.first }
            .prefix(2)
            .map { String($0) }
            .joined()
            .uppercased()
    }

    var body: some View {
        NavigationStack {
            ZStack {
                Color.appBackground.ignoresSafeArea()

                ScrollView(showsIndicators: false) {
                    VStack(spacing: 0) {

                        ZStack(alignment: .bottomLeading) {
                            LinearGradient.mintHeader
                                .frame(height: 160)
                                .ignoresSafeArea()

                            VStack(alignment: .leading, spacing: 4) {
                                Text("Your Support Network")
                                    .font(.appBody(AppFont.bodyMedium))
                                    .foregroundColor(.mintLight)
                                Text("Family & Care")
                                    .font(.appTitle(AppFont.displayMedium))
                                    .foregroundColor(.white)
                            }
                            .padding(.horizontal, 22)
                            .padding(.bottom, 24)
                        }

                        VStack(spacing: 20) {

                            VStack(alignment: .leading, spacing: 12) {
                                Text("Primary Caretaker")
                                    .sectionTitle()

                                HStack(spacing: 16) {
                                    ZStack {
                                        Circle()
                                            .fill(Color.mintLight)
                                            .frame(width: 64, height: 64)
                                        Text(caretakerInitials)
                                            .font(.appBodyBold(AppFont.titleMedium))
                                            .foregroundColor(.mintDark)
                                    }

                                    VStack(alignment: .leading, spacing: 4) {
                                        Text(
                                            firebase.currentUser?.caretakerName.isEmpty == false
                                            ? (firebase.currentUser?.caretakerName ?? "")
                                            : "Your Caretaker"
                                        )
                                        .font(.appBodyBold(AppFont.bodyMedium))
                                        .foregroundColor(.darkText)

                                        Text(firebase.currentUser?.caretakerEmail ?? "")
                                            .font(.appCaption())
                                            .foregroundColor(.grayText)

                                        Text("Connected ✓")
                                            .font(.appCaption(AppFont.tiny))
                                            .foregroundColor(.mintDark)
                                            .padding(.horizontal, 10)
                                            .padding(.vertical, 3)
                                            .background(Color.mintLight)
                                            .cornerRadius(99)
                                    }

                                    Spacer()
                                }
                                .padding(16)
                                .background(Color.white)
                                .cornerRadius(18)
                                .shadow(color: .shadowColor, radius: 6, x: 0, y: 3)
                            }
                            .padding(.horizontal, 20)
                            .padding(.top, 20)

                            VStack(alignment: .leading, spacing: 12) {
                                Text("Quick Actions").sectionTitle()

                                VStack(spacing: 12) {
                                    FamilyActionButton(
                                        icon: "message.fill",
                                        title: "Send a Message",
                                        subtitle: "Text your caretaker",
                                        color: .mintDark
                                    ) { sendMessage() }

                                    FamilyActionButton(
                                        icon: "car.fill",
                                        title: "Request a Ride",
                                        subtitle: "Ask caretaker for transport",
                                        color: .mintDark
                                    ) { requestRide() }

                                }
                            }
                            .padding(.horizontal, 20)

                            VStack(spacing: 6) {
                                Text("\"When the universe is ")
                                    .font(.appTitleItalic(AppFont.bodySmall))
                                    .foregroundColor(.darkText)
                                Text("conspiring to support you\"")
                                    .font(.appTitleItalic(AppFont.bodySmall))
                                    .foregroundColor(.darkText)
                            }
                            .padding(20)
                            .background(Color.white)
                            .cornerRadius(16)
                            .shadow(color: .shadowColor, radius: 8, x: 0, y: 4)
                            .padding(.horizontal, 32)
                        }
                    }
                }
            }
            .navigationBarHidden(true)
            // ── Message composer sheet ────────────────────────────────
            .sheet(isPresented: $showMessageComposer) {
                if let phone = cleanedPhone() {
                    MessageComposerView(recipients: [phone], body: "Hi, I need help.")
                }
            }
            .alert("No Phone Number", isPresented: $showNoPhoneAlert) {
                Button("OK", role: .cancel) {}
            } message: {
                Text("Your caretaker's phone number isn't saved. Please update your profile.")
            }
        }
    }

    private func sendMessage() {
        guard let phone = cleanedPhone() else {
            showNoPhoneAlert = true
            return
        }

        // Use MFMessageComposeViewController if available (real device)
        if MFMessageComposeViewController.canSendText() {
            showMessageComposer = true
        } else {
            // Fallback: open Messages app via URL (works on device, not simulator)
            let encoded = phone.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? phone
            if let url = URL(string: "sms:\(encoded)") {
                UIApplication.shared.open(url)
            }
        }
    }

    private func cleanedPhone() -> String? {
        guard let raw = firebase.currentUser?.caretakerPhone, !raw.isEmpty else { return nil }
        let cleaned = raw
            .replacingOccurrences(of: " ", with: "")
            .replacingOccurrences(of: "-", with: "")
            .replacingOccurrences(of: "(", with: "")
            .replacingOccurrences(of: ")", with: "")
        return cleaned.isEmpty ? nil : cleaned
    }

    private func requestRide() {
        guard let user = firebase.currentUser else { return }
        firebase.sendAlert(
            caretakerEmail: user.caretakerEmail,
            elderID:        user.id,
            elderName:      user.name,
            message:        "🚗 \(user.name) is requesting a ride.",
            type:           "ride"
        ) { _ in }
    }
}

// MARK: - MFMessageComposeViewController wrapper

struct MessageComposerView: UIViewControllerRepresentable {
    let recipients: [String]
    let body:       String

    func makeUIViewController(context: Context) -> MFMessageComposeViewController {
        let vc           = MFMessageComposeViewController()
        vc.recipients    = recipients
        vc.body          = body
        vc.messageComposeDelegate = context.coordinator
        return vc
    }

    func updateUIViewController(_ uiViewController: MFMessageComposeViewController, context: Context) {}

    func makeCoordinator() -> Coordinator { Coordinator() }

    class Coordinator: NSObject, MFMessageComposeViewControllerDelegate {
        func messageComposeViewController(
            _ controller: MFMessageComposeViewController,
            didFinishWith result: MessageComposeResult
        ) {
            controller.dismiss(animated: true)
        }
    }
}

// MARK: - Family Action Button

struct FamilyActionButton: View {
    let icon:     String
    let title:    String
    let subtitle: String
    let color:    Color
    let action:   () -> Void

    var body: some View {
        Button(action: action) {
            HStack(spacing: 16) {
                ZStack {
                    RoundedRectangle(cornerRadius: 12)
                        .fill(Color.mintLight)
                        .frame(width: 48, height: 48)
                    Image(systemName: icon)
                        .font(.system(size: 18))
                        .foregroundColor(color)
                }
                VStack(alignment: .leading, spacing: 2) {
                    Text(title)
                        .font(.appBodyBold(AppFont.bodyMedium))
                        .foregroundColor(.darkText)
                    Text(subtitle)
                        .font(.appCaption())
                        .foregroundColor(.grayText)
                }
                Spacer()
                Image(systemName: "chevron.right")
                    .foregroundColor(.grayText)
                    .font(.system(size: 14))
            }
            .padding(16)
            .background(Color.white)
            .cornerRadius(16)
            .shadow(color: .shadowColor, radius: 4, x: 0, y: 2)
        }
    }
}

#Preview {
    FamilyView()
}
