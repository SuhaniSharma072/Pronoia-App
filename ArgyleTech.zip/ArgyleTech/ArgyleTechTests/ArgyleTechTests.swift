//
//  ArgyleTechTests.swift
//  ArgyleTechTests
//
//  Created by Suhani Sharmaa on 4/3/26.
//

import Testing
@testable import ArgyleTech

struct ArgyleTechTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
